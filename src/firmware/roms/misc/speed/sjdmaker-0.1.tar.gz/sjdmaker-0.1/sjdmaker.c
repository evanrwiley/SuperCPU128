/*{{{*/
/* sjdmaker.c - A program to create a swedish C64/VIC-20 JiffyDOS ROM image
 *
 * Copyright (C) 2010 GHOSTMOLESTORS
 * 
 * So you have JiffyDOS but your C64 or VIC-20 has swedish keyboard and chargen?
 * Don't fret! This program will let you convert your precious JiffyDOS ROM to a
 * version that is suitable for a swedish C64 or VIC-20.
 * Of course, you will need an EPROM programmer and an UV ereaser to reprogram
 * your JiffyDOS chip.
 * 
 * How to use:
 *
 * For C64:
 * You will need a JiffyDOS 6.01 kernal image (available from http://www.jbrain.com)
 *
 * For VIC-20:
 * You will need a JiffyDOS kernal image (not currently available unless you own one)
 * 		 it will probably not work for the new kernal from jbrain when it comes out
 * 		 ...if it comes out.
 * 		 At the time of writing there is a bounty on commodorebounty.com for a new
 * 		 version of JiffyDOS for the VIC-20.
 * 		 http://www.commodorebounty.com/index.php?option=com_content&view=article&id=57&Itemid=57
 * 		 Donate if you are interested in this port.
 *
 * To make a swedish JiffyDOS ROM:
 * sjdmaker -machine jiffyrom.bin output.bin
 *
 * -machine can be one of -c64, -sx64 or -vic20
 *
 * Output file must not exist or the program will fail.
 *
 * Program written by 0och59kul of GHOSTMOLESTORS
 * Original hack^Wversion by herdware of GHOSTMOLESTORS
 *
 * WARNING:
 * The resulting images has only been /very/ lightly tested.
 *
 * WARNING:
 * There are no sanity tests that checks that you are using the right ROM
 * or command line parameters. Failure of this kind WILL leave you with
 * a unbootable system!
 *
 * Use at your own risk!
 *
 */
/*}}}*/
#include <fcntl.h>
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>

/* Compile time settings and other global stuff */
#include "sjdmaker.h"

#if 0
#include "c128intl.h"
#include "c128se.h"
#endif
#include "c64intl.h"
#include "c64se.h"
#include "sx64intl.h"
#include "sx64se.h"
#include "vc20pal.h"
#include "vc20se.h"


int
main(int argc, char **argv)
{
	int i, jd, sjd;
	int machine;
	size_t romsize;
	unsigned char *sjdos;

	if (argc != 4)
		usage();

	if (!strcmp(argv[1], "-c64")) {
		machine = 64;
		romsize = c64romsize;
		sjdos = calloc(8192, sizeof(char));
	} else if (!strcmp(argv[1], "-sx64")) {
		machine = 100;
		romsize = c64romsize;
		sjdos = calloc(8192, sizeof(char));
#if 0
	} else if (!strcmp(argv[1], "-c128")) {
		machine = 128;
		romsize = c128romsize;
		sjdos = calloc(16384, sizeof(char));
#endif
	} else if (!strcmp(argv[1], "-vic20")) {
		machine = 20;
		romsize = vic20romsize;
		sjdos = calloc(8192, sizeof(char));
	} else {
		fprintf(stderr, "You must choose a machine type.\n");
		exit(EXIT_FAILURE);
	}

	if (sjdos == NULL) {
		fprintf(stderr, "Could not allocate memory!\n");
		fflush(stderr);
		perror(NULL);
		exit(EXIT_FAILURE);
	}

	jd = open(argv[2], O_RDONLY, 0);
	if (jd == -1) {
		fprintf(stderr, "%s", argv[2]);
		fflush(stderr);
		perror(NULL);
		exit(EXIT_FAILURE);
	}
	
	if (read(jd, sjdos, romsize) == -1) {
		fprintf(stderr, "Unable to read %s", argv[2]);
		fflush(stderr);
		perror(NULL);
		exit(EXIT_FAILURE);
	}
	close(jd);

	switch(machine) {
		case 64:
			for (i = 0; i < c64romsize; i++) {
				if (c64swe[i] != c64intl[i])
					sjdos[i] = c64swe[i];
			}
			break;

		case 100:
			for (i = 0; i < c64romsize; i++) {
				if (sx64swe[i] != sx64intl[i])
					sjdos[i] = sx64swe[i];
			}
			break;

		case 128:
			/*{{{ No C128 version available! */
			/* There is a rumour going around that a Swedish
			 * version of JiffyDOS exists created by a Swedish
			 * C128 hacker. I have never seen it. Conversion
			 * to Swedish version is not as trivial as C64/VIC-20.
			 * If you want to know why, compare the Swedish
			 * and International kernals.
			 *
			 * I can not make a C128 converter without it.
			 */
			/*}}}*/
			fprintf(stderr, "C128 is not supported yet!\n");
			exit(EXIT_FAILURE);
			break;

		case 20:
			for (i = 0; i < vic20romsize; i++) {
				if (vic20swe[i] != vic20pal[i]) {
					/* The swedish VIC-20 uses another fill byte :/ */
					if (vic20pal[i] == 0xff && vic20swe[i] == 0xaa) {
						continue;
					} else { 
						/* Don't touch this area! Handic changed {{{ 
						 * it and nobody knows why. There's supposed
						 * to be a patched tape routine here. I
						 * don't know what the routine does in
						 * the swedish one but afaict it's not
						 * called from anywhere and it makes
						 * the swedish VIC crash under certain
						 * circumstances!
						 * JiffyDOS puts code in this area so
						 * the ROM will not work if it gets touched!
						 * }}} */
						if (i < 0x4cf || i > 0x4e8)
							sjdos[i] = vic20swe[i];
					}
				}
			}
			break;

		default:
			fprintf(stderr, "Undefined machine!\n");
			exit(EXIT_FAILURE);
	}

	sjd = open(argv[3], O_WRONLY|O_CREAT|O_EXCL, S_IRUSR|S_IWUSR|S_IRGRP|S_IROTH);
	if (sjd == -1) {
		fprintf(stderr, "Could not open %s for writing", argv[3]);
		fflush(stderr);
		perror(NULL);
		exit(EXIT_FAILURE);
	}
	if (write(sjd, sjdos, romsize) == -1) {
		fprintf(stderr, "Write failed");
		fflush(stderr);
		perror(NULL);
		exit(EXIT_FAILURE);
	}
	close(sjd);
	free(sjdos);
	return 0;
}

void
usage(void)
{
	fprintf(stderr, "0och59kul/GHOSTMOLESTORS presents\nsjdmaker "SJDMKVERSION", A program to convert C64/SX64/VIC-20 JiffyDOS kernals\n\t  to versions suitable for machines with swedish character\n\t  generators\n\n");
	fprintf(stderr, "usage: sjdmaker -{c64|sx64|vic20} jdkernal outfile\n");
	exit(EXIT_FAILURE);
}
