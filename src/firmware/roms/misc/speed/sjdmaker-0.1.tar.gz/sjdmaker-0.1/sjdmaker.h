#ifndef __SJDMAKER_H
#define __SJDMAKER_H

#define SJDMKVERSION "0.1"
/* Use the patched (crash on tape file close) Swedish VIC20 kernal as template.
 * Remove to use original version.
 */
#define USE_PATCHED_VIC20SE


/* The three sizes. Get it? Bust, Waist, Hips? No? Well, screw you then! Hmmpf! */
const unsigned int c64romsize = 8192;
const unsigned int vic20romsize = 8192;
#if 0
const unsigned int c128romsize = 16384;
#endif

void usage(void);
#endif /* __SJDMAKER_H */
