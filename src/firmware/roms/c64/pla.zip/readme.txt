PLA.EXE

C64 PLA analyzer program / memory map lister

(C)2002,03 Jens Sch�nfeld - www.jschoenfeld.de, www.c64upgra.de, www.ami.ga
this program is freeware. No part of this archive may be changed.

This archive countains:

PLA.EXE      main program, runs on DOS or in a DOS box
PLA.BIN      binary data, must be in the same directory as PLA.EXE
PLA.PAS      Borland Pascal 5.0 source code
readme.txt   this file

no other files belong here.

This program is provided "as is" with no warranties or liabilities at all. If
you kill your dog with the microwave during the use of this program, it's not
my responsibility. The source is included for educational purpose, please send
me any changes you're making to this thing, or 3d-animated OpenGL versions of
the program :-)

What it does
------------
the program visualizes the C64 memory map depending on the contents of the
$01 register and the external lines of the expansion port.

How to use
----------
The program is written and compiled in Borland Turbo Pascal V5.5 (should also
compile under 5.0) and uses plain DOS or a DOS box of any compatible operating 
system. 

The program should be pretty self-explanatory. Press the keys 1-6, c or q to
toggle the lines or quit. The screen is updated instantly. There is only one
screen. The left column shows the memory map for CPU read accesses, the
middle column shows CPU write accesses, and the right column shows VIC
accesses (which are always read, VIC cannot write!). Loram, Hiram and Charen
are the names of the lower three bits of the $01 register. The screen also
shows a value for the $01 register that sets the shown memory map.

Toggling the BA or CAS line will not be of any use to you. Leave them as they
are upon startup of the program. They may be of interest, if you know the
internals of the C64 hardware. Also, the . or * after each bank name are not
interesting for you if you don't know the C64 schematics. If you don't
understand it, ignore it, you'll be happier than with trying to understand
what it means.

Why?
----
I have reverse-engineered the PLA chip of the C64, and this program was made
during the process of reverse engineering. The PLA.BIN file is exactly the
one that I have posted to a German newsgroup in August 1994. I found my 
records, and took the time to finally finish my job, since nobody else
really found a nice solution for the casram equation.
PLA replacements have been produced in the meantime. There are minor timing-
issues with the plus/4 version of my "super-PLA", I hope it's not going to 
take another 8 years until I'll correct that one. The product uses MACH chips
to implement the logic. I have published the sources of the verified "known
good" sources on ftp.funet.fi (that's C64, 2x 264 series and the 610/710).
The binary images of other PLAs are also published there, just check the 
other archives.

I also found the program useful when coding, that's why I share it with the
community. If you like it, send me an eMail: jens@schoenfeld.de.

source
------
I'm a hardware designer. I cannot code. The code is a mess. Take it, laugh
at it, but only send me improvements if you add functionality. I hate to
feel inferior because you solved it in a tenth of the space at 200 times
the speed ;-)

future
------
I think I won't do anything on this program any more. You may want to port
it to some GUI based operating system, add some nice clicky features, or do
the transition from one memory map to another with 3D graphics animations - 
the fame of being the first is all yours. Just include the four files of
this archive unmodified with your work, and make it available to the 
community for free.

thanks
------
- fox/starlight for early betatesting.
- Jeri Ellsworth for kicking my ass to design a *nice* PCB for the
  PLA replacement (yes, it's hand-routed!)
- Andreas Boose for early logic reverse-engineering in 1996
- Daniele Gratteri for the 82S100 datasheet PDF
- Marko M�kel� for maintaining ftp.funet.fi

hint
----
The reason why you all failed on minimizing the CASRAM equation was that it's 
realized active-high in the 82S100 chip. Note that this chip has ExOR fuses 
for outputs, and kind-of-a-feedback can be done by multi-using product terms
for multiple outputs (a feature that today's programmable logic does not
have, so you have to do it with real feedbacks, which may result in timing
issues).

--eof
