#include <stdio.h>
#include <stdlib.h>

unsigned long i;
int port=0x378;

void main(int argc,char *argv[])
{
 FILE *out;

 out=fopen(argv[1],"wb");
 outp(port+2,0x06); //set all data lines HIGH and then switch to input
 outp(port+0,0xff);
 outp(port+2,0x2c); //and reset external counter, preset /C3=L /C0=L
 printf("Please connect the PLA-reader now and apply power to it, then press a key\n");
 getch();
 printf("working... This may take some minutes");
 for (i=0;i<0x1000000;i++)
 {
// fputc((((inp(port+1)^0x80)&0xf8)|(inp(port+2)&0x04))>>2,out);
 //bit 7 of SR must be inverted, bits 2-0 are masked out, this is ORed with
 //bit 2 of CR and then shifted to the right.
 fputc(inp(port+0)&15,out); //data from DR
 outp(port+2,0x2e); // /C0=H, /C3=L
 outp(port+2,0x2f); // /C0=L counter advances on HL edge
 }
 for (i=0;i<0x1000000;i++)
 {
// fputc((((inp(port+1)^0x80)&0xf8)|(inp(port+2)&0x04))>>2,out);
 fputc(inp(port+0)&15,out); //data from DR
 outp(port+2,0x26); // /C0=H,  /C3=H
 outp(port+2,0x27); // /C0=L counter advances on HL edge
 }
 for (i=0;i<0x1000000;i++)
 {
 outp(port+2,0x2e); // /C0=H, /C3=L
// fputc((((inp(port+1)^0x80)&0xf8)|(inp(port+2)&0x04))>>2,out);
 fputc(inp(port+0)&15,out); //data from DR
 outp(port+2,0x2f); // /C0=L counter advances on HL edge
 }
 for (i=0;i<0x1000000;i++)
 {
 outp(port+2,0x26); // /C0=H,  /C3=H
// fputc((((inp(port+1)^0x80)&0xf8)|(inp(port+2)&0x04))>>2,out);
 fputc(inp(port+0)&15,out); //data from DR
 outp(port+2,0x27); // /C0=L counter advances on HL edge
 }
 fclose(out);
}